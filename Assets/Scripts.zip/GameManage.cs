﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManage : MonoBehaviour
{    
    public void QuitGame()
    {
        Application.Quit();
    }
}
